import sys
import os

# Add the current directory to sys.path to ensure local modules are found
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd

from analysis import TicketAnalyzer
from predictor import TicketPredictor

app = Flask(__name__)
CORS(app)

analyzer = None
predictor = None

def load_data(filepath=None):
    global analyzer, predictor
    if filepath is None:
        filepath = os.path.join(os.path.dirname(__file__), '..', 'data', 'tickets.csv')
    
    df = pd.read_csv(filepath, parse_dates=['Created'])
    analyzer = TicketAnalyzer(df)
    predictor = TicketPredictor(df)
    print(f"Loaded {len(df)} tickets from {filepath}")

@app.route('/api/heavy-hitters', methods=['GET'])
def get_heavy_hitters():
    top_n = request.args.get('top_n', 10, type=int)
    result = analyzer.get_heavy_hitters(top_n)
    return jsonify(result)

@app.route('/api/effort-analysis', methods=['GET'])
def get_effort_analysis():
    result = analyzer.get_effort_by_item()
    return jsonify(result)

@app.route('/api/volume-trends', methods=['GET'])
def get_volume_trends():
    granularity = request.args.get('granularity', 'monthly')
    result = analyzer.get_volume_trends(granularity)
    return jsonify(result)

@app.route('/api/predictions', methods=['GET'])
def get_predictions():
    result = predictor.predict_next_year()
    return jsonify(result)

@app.route('/api/summary', methods=['GET'])
def get_summary():
    result = analyzer.get_summary()
    return jsonify(result)

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "message": "API is running"})

if __name__ == '__main__':
    load_data()
    app.run(debug=True, port=5000)
