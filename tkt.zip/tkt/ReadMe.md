# Ticket Analysis Dashboard

A full-stack application to analyze ServiceNow ticket data, identify heavy hitters, track effort, and predict future trends.

## Features

- **Heavy Hitters Analysis**: Identify top ticket items by volume with Pareto analysis
- **Effort Tracking**: Analyze time spent per ticket category
- **Volume Trends**: Visualize ticket trends over time
- **Predictions**: ML-based forecasting for the next 12 months

## Quick Start

### 1. Backend Setup

```bash
cd backend
pip install -r requirements.txt
python app.py
