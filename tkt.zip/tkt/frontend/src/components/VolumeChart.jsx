import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

function VolumeChart({ data }) {
    const [showItemTrends, setShowItemTrends] = useState(false);

    if (!data) return <p>No data available</p>;

    const { overall_trend, item_trends } = data;

    if (!overall_trend || overall_trend.length === 0) {
        return <p>No trend data available</p>;
    }

    return (
        <div className="volume-chart">
            <div className="chart-controls">
                <button
                    className={!showItemTrends ? 'active' : ''}
                    onClick={() => setShowItemTrends(false)}
                >
                    Overall Volume
                </button>
                <button
                    className={showItemTrends ? 'active' : ''}
                    onClick={() => setShowItemTrends(true)}
                >
                    By Top Items
                </button>
            </div>

            {!showItemTrends ? (
                <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={overall_trend} margin={{ bottom: 50 }}>
                        <XAxis
                            dataKey="period"
                            tick={{ fontSize: 10 }}
                            angle={-45}
                            textAnchor="end"
                            height={60}
                            interval="preserveStartEnd"
                        />
                        <YAxis />
                        <Tooltip />
                        <Line
                            type="monotone"
                            dataKey="count"
                            stroke="#4f46e5"
                            strokeWidth={2}
                            dot={{ r: 3 }}
                            name="Ticket Volume"
                        />
                    </LineChart>
                </ResponsiveContainer>
            ) : (
                <ResponsiveContainer width="100%" height={300}>
                    <LineChart margin={{ bottom: 50 }}>
                        <XAxis
                            dataKey="period"
                            tick={{ fontSize: 10 }}
                            angle={-45}
                            textAnchor="end"
                            height={60}
                            allowDuplicatedCategory={false}
                            interval="preserveStartEnd"
                        />
                        <YAxis />
                        <Tooltip />
                        <Legend wrapperStyle={{ paddingTop: '20px' }} />
                        {Object.entries(item_trends || {}).map(([item, trend], idx) => (
                            <Line
                                key={item}
                                data={trend}
                                type="monotone"
                                dataKey="count"
                                stroke={COLORS[idx % COLORS.length]}
                                strokeWidth={2}
                                dot={{ r: 2 }}
                                name={item.length > 15 ? item.substring(0, 13) + '...' : item}
                            />
                        ))}
                    </LineChart>
                </ResponsiveContainer>
            )}
        </div>
    );
}

export default VolumeChart;
