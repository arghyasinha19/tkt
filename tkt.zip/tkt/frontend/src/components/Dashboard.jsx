import React from 'react';
import HeavyHitters from './HeavyHitters';
import EffortAnalysis from './EffortAnalysis';
import Predictions from './Predictions';
import VolumeChart from './VolumeChart';

function Dashboard({ data, onRefresh }) {
    const { summary, heavyHitters, effortAnalysis, volumeTrends, predictions } = data;

    return (
        <div className="dashboard">
            <header className="dashboard-header">
                <div className="header-top">
                    <h1>🎫 Ticket Analysis Dashboard</h1>
                    <button className="refresh-btn" onClick={onRefresh}>↻ Refresh</button>
                </div>

                {summary && (
                    <div className="summary-stats">
                        <div className="stat-card">
                            <span className="stat-value">{summary.total_tickets?.toLocaleString()}</span>
                            <span className="stat-label">Total Tickets</span>
                        </div>
                        <div className="stat-card">
                            <span className="stat-value">{summary.unique_items}</span>
                            <span className="stat-label">Unique Items</span>
                        </div>
                        <div className="stat-card">
                            <span className="stat-value">{summary.unique_categories}</span>
                            <span className="stat-label">Categories</span>
                        </div>
                        <div className="stat-card">
                            <span className="stat-value">{summary.avg_daily_tickets}</span>
                            <span className="stat-label">Avg Daily Volume</span>
                        </div>
                        <div className="stat-card highlight">
                            <span className="stat-value">{summary.top_item}</span>
                            <span className="stat-label">Top Item</span>
                        </div>
                    </div>
                )}

                {summary?.date_range && (
                    <p className="date-range">
                        Data range: {summary.date_range.start} to {summary.date_range.end}
                    </p>
                )}
            </header>

            <div className="dashboard-grid">
                <section className="card heavy-hitters-section">
                    <h2>🔥 Heavy Hitters (Top Items by Volume)</h2>
                    <HeavyHitters data={heavyHitters} />
                </section>

                <section className="card effort-section">
                    <h2>⏱️ Effort Analysis</h2>
                    <EffortAnalysis data={effortAnalysis} />
                </section>

                <section className="card volume-section">
                    <h2>📈 Volume Trends</h2>
                    <VolumeChart data={volumeTrends} />
                </section>

                <section className="card predictions-section">
                    <h2>🔮 Predicted Heavy Hitters (Next 12 Months)</h2>
                    <Predictions data={predictions} />
                </section>
            </div>
        </div>
    );
}

export default Dashboard;
