import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

function EffortAnalysis({ data }) {
    if (!data) return <p>No data available</p>;

    const { effort_analysis, total_effort_hours, avg_effort_per_ticket } = data;

    return (
        <div className="effort-analysis">
            <div className="effort-summary">
                <div className="metric">
                    <span className="metric-value">{total_effort_hours.toLocaleString()}</span>
                    <span className="metric-label">Total Hours</span>
                </div>
                <div className="metric">
                    <span className="metric-value">{avg_effort_per_ticket}</span>
                    <span className="metric-label">Avg Hours/Ticket</span>
                </div>
            </div>

            <ResponsiveContainer width="100%" height={280}>
                <BarChart data={effort_analysis.slice(0, 10)} layout="vertical" margin={{ left: 20, right: 20 }}>
                    <XAxis type="number" />
                    <YAxis
                        type="category"
                        dataKey="item"
                        width={140}
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => value.length > 20 ? value.substring(0, 18) + '...' : value}
                    />
                    <Tooltip
                        formatter={(value) => [`${value.toLocaleString()} hours`, 'Total Effort']}
                    />
                    <Bar dataKey="total_hours" fill="#10b981" radius={[0, 4, 4, 0]} />
                </BarChart>
            </ResponsiveContainer>

            <div className="table-container">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Tickets</th>
                            <th>Total Hrs</th>
                            <th>Avg Hrs</th>
                        </tr>
                    </thead>
                    <tbody>
                        {effort_analysis.slice(0, 10).map((item) => (
                            <tr key={item.item}>
                                <td className="item-name" title={item.item}>{item.item}</td>
                                <td className="number">{item.ticket_count.toLocaleString()}</td>
                                <td className="number">{item.total_hours.toLocaleString()}</td>
                                <td className="number">{item.avg_hours}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default EffortAnalysis;
