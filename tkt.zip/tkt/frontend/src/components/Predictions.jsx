import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

function Predictions({ data }) {
    const [selectedItem, setSelectedItem] = useState(null);

    if (!data) return <p>No data available</p>;

    const { predicted_heavy_hitters, predictions_by_item, prediction_period } = data;

    if (!predicted_heavy_hitters || predicted_heavy_hitters.length === 0) {
        return <p>Insufficient historical data for predictions</p>;
    }

    const selectedPrediction = selectedItem ? predictions_by_item[selectedItem] : null;

    const chartData = selectedPrediction
        ? [
            ...selectedPrediction.historical.map((h) => ({
                period: h.period,
                historical: h.count,
                predicted: null
            })),
            ...selectedPrediction.monthly_predictions.map((p) => ({
                period: p.period,
                historical: null,
                predicted: p.predicted_count
            }))
        ]
        : [];

    return (
        <div className="predictions">
            {prediction_period?.start && (
                <p className="prediction-period">
                    Forecast: {prediction_period.start} → {prediction_period.end}
                </p>
            )}

            <div className="predictions-layout">
                <div className="predicted-rankings">
                    <div className="table-container">
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Item</th>
                                    <th>Predicted</th>
                                    <th>Current</th>
                                    <th>Trend</th>
                                </tr>
                            </thead>
                            <tbody>
                                {predicted_heavy_hitters.map((item) => {
                                    const change = item.predicted_annual_count - item.current_annual_rate;
                                    const changePercent = item.current_annual_rate > 0
                                        ? ((change / item.current_annual_rate) * 100).toFixed(1)
                                        : 0;

                                    return (
                                        <tr
                                            key={item.item}
                                            className={selectedItem === item.item ? 'selected' : ''}
                                            onClick={() => setSelectedItem(selectedItem === item.item ? null : item.item)}
                                        >
                                            <td className="rank">{item.rank}</td>
                                            <td className="item-name" title={item.item}>
                                                {item.item.length > 18 ? item.item.substring(0, 16) + '...' : item.item}
                                            </td>
                                            <td className="number">{item.predicted_annual_count.toLocaleString()}</td>
                                            <td className="number">{item.current_annual_rate.toLocaleString()}</td>
                                            <td className={change >= 0 ? 'trend-up' : 'trend-down'}>
                                                {change >= 0 ? '↑' : '↓'} {Math.abs(changePercent)}%
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                    <p className="table-hint">Click a row to see the forecast chart</p>
                </div>

                {selectedPrediction && (
                    <div className="prediction-chart">
                        <h4>
                            {selectedItem}
                            <span className={`confidence confidence-${selectedPrediction.confidence}`}>
                                {selectedPrediction.confidence} confidence
                            </span>
                        </h4>
                        <ResponsiveContainer width="100%" height={220}>
                            <AreaChart data={chartData} margin={{ bottom: 40 }}>
                                <XAxis
                                    dataKey="period"
                                    tick={{ fontSize: 9 }}
                                    angle={-45}
                                    textAnchor="end"
                                    height={50}
                                    interval={2}
                                />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Area
                                    type="monotone"
                                    dataKey="historical"
                                    stroke="#4f46e5"
                                    fill="#c7d2fe"
                                    name="Historical"
                                    connectNulls={false}
                                />
                                <Area
                                    type="monotone"
                                    dataKey="predicted"
                                    stroke="#10b981"
                                    fill="#a7f3d0"
                                    strokeDasharray="5 5"
                                    name="Predicted"
                                    connectNulls={false}
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                )}
            </div>
        </div>
    );
}

export default Predictions;
