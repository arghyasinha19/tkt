import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const COLORS = ['#4f46e5', '#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe', '#e0e7ff'];

function HeavyHitters({ data }) {
    if (!data) return <p>No data available</p>;

    const { heavy_hitters, total_tickets, top_n_coverage } = data;

    return (
        <div className="heavy-hitters">
            <div className="coverage-badge">
                Top {heavy_hitters.length} items account for <strong>{top_n_coverage}%</strong> of all tickets
            </div>

            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={heavy_hitters} layout="vertical" margin={{ left: 20, right: 20 }}>
                    <XAxis type="number" />
                    <YAxis
                        type="category"
                        dataKey="item"
                        width={140}
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => value.length > 20 ? value.substring(0, 18) + '...' : value}
                    />
                    <Tooltip
                        formatter={(value) => [`${value.toLocaleString()} tickets`, 'Volume']}
                        labelFormatter={(label) => `Item: ${label}`}
                    />
                    <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                        {heavy_hitters.map((entry, index) => (
                            <Cell key={entry.item} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </Bar>
                </BarChart>
            </ResponsiveContainer>

            <div className="table-container">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Item</th>
                            <th>Count</th>
                            <th>%</th>
                            <th>Cumulative</th>
                        </tr>
                    </thead>
                    <tbody>
                        {heavy_hitters.map((item, idx) => (
                            <tr key={item.item}>
                                <td className="rank">{idx + 1}</td>
                                <td className="item-name" title={item.item}>{item.item}</td>
                                <td className="number">{item.count.toLocaleString()}</td>
                                <td className="number">{item.percentage}%</td>
                                <td>
                                    <div className="progress-bar">
                                        <div
                                            className="progress-fill"
                                            style={{ width: `${Math.min(item.cumulative_percentage, 100)}%` }}
                                        />
                                        <span className="progress-text">{item.cumulative_percentage}%</span>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default HeavyHitters;
