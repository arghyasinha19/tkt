import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Dashboard from './components/Dashboard';

const API_BASE = 'http://localhost:5000/api';

function App() {
    const [data, setData] = useState({
        summary: null,
        heavyHitters: null,
        effortAnalysis: null,
        volumeTrends: null,
        predictions: null
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchAllData();
    }, []);

    const fetchAllData = async () => {
        try {
            setLoading(true);
            setError(null);

            const [summary, heavyHitters, effort, volume, predictions] = await Promise.all([
                axios.get(`${API_BASE}/summary`),
                axios.get(`${API_BASE}/heavy-hitters?top_n=10`),
                axios.get(`${API_BASE}/effort-analysis`),
                axios.get(`${API_BASE}/volume-trends?granularity=monthly`),
                axios.get(`${API_BASE}/predictions`)
            ]);

            setData({
                summary: summary.data,
                heavyHitters: heavyHitters.data,
                effortAnalysis: effort.data,
                volumeTrends: volume.data,
                predictions: predictions.data
            });
        } catch (err) {
            setError(err.response?.data?.message || err.message || 'Failed to fetch data');
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="loading-container">
                <div className="spinner"></div>
                <p>Loading ticket analysis...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="error-container">
                <h2>Error Loading Data</h2>
                <p>{error}</p>
                <button onClick={fetchAllData}>Retry</button>
            </div>
        );
    }

    return <Dashboard data={data} onRefresh={fetchAllData} />;
}

export default App;
