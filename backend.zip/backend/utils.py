import pandas as pd
import numpy as np
import re
from sklearn.cluster import AgglomerativeClustering
from transformers import AutoTokenizer, AutoModel
import torch

_tokenizer = None
_model = None

def get_model():
    global _tokenizer, _model
    if _model is None:
        model_name = "distilbert-base-uncased"
        _tokenizer = AutoTokenizer.from_pretrained(model_name)
        _model = AutoModel.from_pretrained(model_name)
    return _tokenizer, _model

def get_embeddings(texts):
    tokenizer, model = get_model()
    inputs = tokenizer(texts, padding=True, truncation=True, return_tensors="pt", max_length=128)
    with torch.no_grad():
        outputs = model(**inputs)
    # Use mean pooling of the last hidden state
    embeddings = outputs.last_hidden_state.mean(dim=1)
    return embeddings.numpy()

def group_by_semantic_similarity(df, mask, column='Short Description', distance_threshold=0.3):
    """
    Groups rows in df[mask] by semantic similarity of the specified column.
    Returns a series with the same index as df[mask] containing the representative label.
    """
    subset = df[mask].copy()
    # Normalize for initial grouping/deduplication
    def pre_normalize(text):
        if pd.isnull(text) or not str(text).strip():
            return "unspecified request"
        clean = re.sub(r'[^\w\s]', ' ', str(text).lower())
        return " ".join(clean.split())

    subset['normalized_desc'] = subset[column].apply(pre_normalize)
    unique_descriptions = subset['normalized_desc'].unique()
    
    if len(unique_descriptions) < 2:
        return subset['normalized_desc']

    # Get embeddings for unique descriptions
    embeddings = get_embeddings(unique_descriptions.tolist())
    
    # Perform clustering
    # distance_threshold depends on the embedding space; 0.3 is a starting point for cosine-like distance
    clustering = AgglomerativeClustering(
        n_clusters=None, 
        distance_threshold=distance_threshold,
        metric='cosine', 
        linkage='average'
    )
    cluster_labels = clustering.fit_predict(embeddings)
    
    # Map unique descriptions to their cluster's "best" representative (the most frequent original one)
    cluster_to_rep = {}
    for cluster_id in np.unique(cluster_labels):
        indices = np.where(cluster_labels == cluster_id)[0]
        descs_in_cluster = unique_descriptions[indices]
        # Find the most frequent normalized description in the original subset for this cluster
        freq = subset[subset['normalized_desc'].isin(descs_in_cluster)]['normalized_desc'].value_counts()
        cluster_to_rep[cluster_id] = freq.index[0]

    # Map each unique description back to its cluster representative
    desc_to_rep = {desc: cluster_to_rep[label] for desc, label in zip(unique_descriptions, cluster_labels)}
    
def predict_subcategories(df, mask, column='Short Description'):
    """
    Predicts Sub Category 1 and Sub Category 2 for tickets in df[mask]
    based on the intent of the 'column' using tickets with known sub-categories as reference.
    """
    from sklearn.neighbors import KNeighborsClassifier
    
    # 1. Identify "Reference Set" (tickets with valid Sub Category 1 and 2)
    s1, s2 = 'Sub Category 1', 'Sub Category 2'
    if s1 not in df.columns or s2 not in df.columns:
        return df.loc[mask, 'Item'] # Cannot predict without columns

    reference_mask = pd.notnull(df[s1]) & pd.notnull(df[s2]) & \
                     (df[s1].str.strip() != "") & (df[s2].str.strip() != "") & \
                     (~df[s1].str.contains('other', case=False, na=False)) & \
                     (~df[s2].str.contains('other', case=False, na=False))
    
    # If no reference data, fall back to basic grouping or previous logic
    if not df[reference_mask].any() or len(df[reference_mask]) < 2:
        return group_by_semantic_similarity(df, mask, column)

    ref_df = df[reference_mask].copy()
    ref_df['combined_subcat'] = ref_df[s1].str.strip() + " - " + ref_df[s2].str.strip()
    
    query_df = df[mask].copy()
    
    # 2. Extract Embeddings
    ref_embeddings = get_embeddings(ref_df[column].fillna("").tolist())
    query_embeddings = get_embeddings(query_df[column].fillna("").tolist())
    
    # 3. Train KNN Classifier
    # We use 1-nearest neighbor to find the most similar intent
    knn = KNeighborsClassifier(n_neighbors=1, metric='cosine')
    knn.fit(ref_embeddings, ref_df['combined_subcat'])
    
    # 4. Predict
    predictions = knn.predict(query_embeddings)
    
    return pd.Series(predictions, index=query_df.index)
