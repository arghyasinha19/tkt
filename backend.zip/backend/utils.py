import pandas as pd
import numpy as np
import re
from sklearn.cluster import AgglomerativeClustering
from transformers import AutoTokenizer, AutoModel
import torch

_tokenizer = None
_model = None

def get_model():
    global _tokenizer, _model
    if _model is None:
        model_name = "distilbert-base-uncased"
        _tokenizer = AutoTokenizer.from_pretrained(model_name)
        _model = AutoModel.from_pretrained(model_name)
    return _tokenizer, _model

def get_embeddings(texts):
    tokenizer, model = get_model()
    inputs = tokenizer(texts, padding=True, truncation=True, return_tensors="pt", max_length=128)
    with torch.no_grad():
        outputs = model(**inputs)
    # Use mean pooling of the last hidden state
    embeddings = outputs.last_hidden_state.mean(dim=1)
    return embeddings.numpy()

def group_by_semantic_similarity(df, mask, column='Short Description', distance_threshold=0.3):
    """
    Groups rows in df[mask] by semantic similarity of the specified column.
    Returns a series with the same index as df[mask] containing the representative label.
    """
    subset = df[mask].copy()
    # Normalize for initial grouping/deduplication
    def pre_normalize(text):
        if pd.isnull(text) or not str(text).strip():
            return "unspecified request"
        clean = re.sub(r'[^\w\s]', ' ', str(text).lower())
        return " ".join(clean.split())

    subset['normalized_desc'] = subset[column].apply(pre_normalize)
    unique_descriptions = subset['normalized_desc'].unique()
    
    if len(unique_descriptions) < 2:
        return subset['normalized_desc']

    # Get embeddings for unique descriptions
    embeddings = get_embeddings(unique_descriptions.tolist())
    
    # Perform clustering
    # distance_threshold depends on the embedding space; 0.3 is a starting point for cosine-like distance
    clustering = AgglomerativeClustering(
        n_clusters=None, 
        distance_threshold=distance_threshold,
        metric='cosine', 
        linkage='average'
    )
    cluster_labels = clustering.fit_predict(embeddings)
    
    # Map unique descriptions to their cluster's "best" representative (the most frequent original one)
    cluster_to_rep = {}
    for cluster_id in np.unique(cluster_labels):
        indices = np.where(cluster_labels == cluster_id)[0]
        descs_in_cluster = unique_descriptions[indices]
        # Find the most frequent normalized description in the original subset for this cluster
        freq = subset[subset['normalized_desc'].isin(descs_in_cluster)]['normalized_desc'].value_counts()
        cluster_to_rep[cluster_id] = freq.index[0]

    # Map each unique description back to its cluster representative
    desc_to_rep = {desc: cluster_to_rep[label] for desc, label in zip(unique_descriptions, cluster_labels)}
    
    return subset['normalized_desc'].map(desc_to_rep)
